#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <errno.h>

#define PORT 8080
#define LOG_FILE "client_log.txt"

int client_running = 1;
sem_t client_semaphore;  // Add semaphore for client synchronization

void log_error(const char *message) {
    FILE *log_file = fopen(LOG_FILE, "a");
    if (log_file == NULL) {
        perror("Failed to open log file");
        return;
    }
    fprintf(log_file, "ERROR: %s: %s\n", message, strerror(errno));
    fclose(log_file);
}

void show_menu() {
    printf("\n=== Client Menu ===\n");
    printf("1. Send Message\n");
    printf("2. Exit\n");
    printf("Enter choice: ");
}

void *receive_messages(void *socket_desc) {
    int sock = *(int*)socket_desc;
    char server_message[1024];
    int read_size;

    while (client_running && (read_size = recv(sock, server_message, 1024, 0)) > 0) {
        server_message[read_size] = '\0';
        
        sem_wait(&client_semaphore);  // Protect shared resource access
        if (strcmp(server_message, "SERVER_SHUTDOWN") == 0) {
            printf("\nServer is shutting down. Press Enter to exit...\n");
            client_running = 0;
            sem_post(&client_semaphore);
            break;
        }
        
        if (strncmp(server_message, "SERVER:", 7) == 0) {
            printf("\n%s\n", server_message);
        }
        
        if (client_running) {
            fflush(stdout);
        }
        sem_post(&client_semaphore);  // Release semaphore
    }

    sem_wait(&client_semaphore);
    if (read_size == 0 && client_running) {
        printf("\nServer disconnected\n");
        client_running = 0;
    } else if (read_size == -1 && client_running) {
        perror("recv failed");
        log_error("recv failed");
        client_running = 0;
    }
    sem_post(&client_semaphore);

    return 0;
}

int main() {
    int sock;
    struct sockaddr_in server;
    char message[1024];
    pthread_t thread_id;
    int choice;
    char input[10];

    // Initialize semaphore
    if (sem_init(&client_semaphore, 0, 1) < 0) {
        perror("Semaphore initialization failed");
        return 1;
    }

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        perror("Could not create socket");
        log_error("Could not create socket");
        return 1;
    }

    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons(PORT);

    if (connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("connect failed");
        log_error("connect failed");
        return 1;
    }
    printf("Connected to server\n");

    if (pthread_create(&thread_id, NULL, receive_messages, (void*)&sock) < 0) {
        perror("could not create thread");
        log_error("could not create thread");
        return 1;
    }

    while (client_running) {
        show_menu();
        fgets(input, sizeof(input), stdin);
        choice = atoi(input);

        sem_wait(&client_semaphore);  // Protect shared resource access
        switch (choice) {
            case 1:
                printf("Enter message: ");
                fgets(message, 1024, stdin);
                message[strcspn(message, "\n")] = '\0';
                
                if (send(sock, message, strlen(message), 0) < 0) {
                    perror("Send failed");
                    log_error("Send failed");
                    client_running = 0;
                } else {
                    printf("Message sent to server\n");
                }
                break;
                
            case 2:
                printf("Exiting...\n");
                client_running = 0;
                break;
                
            default:
                printf("Invalid choice!\n");
        }
        sem_post(&client_semaphore);  // Release semaphore
    }

    sem_destroy(&client_semaphore);
    close(sock);
    return 0;
}