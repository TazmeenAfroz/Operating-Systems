#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#define tasks_n 10
#define time_quantum 5


typedef struct {
    char name[10];
    int priority;
    int cpuBurst;
    int remainingTime;
    int waitingTime;
    int turnaroundTime;
    int completed;
} Task;

// Function to print horizontal line
void printLine(int width) {
    for(int i = 0; i < width; i++) printf("-");
    printf("\n");
}

// Function to print formatted table
void printScheduleTable(Task tasks[], int n, const char* algorithm) {
    printf("\n%s Scheduling Results:\n", algorithm);
    printLine(75);
    printf("| %-8s | %-8s | %-12s | %-15s | %-15s |\n", 
           "Task", "Priority", "Burst Time", "Waiting Time", "Turnaround Time");
    printLine(75);
    
    float avgWait = 0, avgTurnaround = 0;
    
    for (int i = 0; i < n; i++) {
        printf("| %-8s | %-8d | %-12d | %-15d | %-15d |\n",
               tasks[i].name, 
               tasks[i].priority,
               tasks[i].cpuBurst,
               tasks[i].waitingTime,
               tasks[i].turnaroundTime);
        avgWait += tasks[i].waitingTime;
        avgTurnaround += tasks[i].turnaroundTime;
    }
    
    printLine(75);
    printf("Average Waiting Time: %.2f\n", avgWait/n);
    printf("Average Turnaround Time: %.2f\n", avgTurnaround/n);
}

// Function to load tasks from file
int loadTasks(Task tasks[], const char* filename) {
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file!\n");
        return 0;
    }

    int n = 0;
    while (fscanf(file, "%[^,], %d, %d\n", 
           tasks[n].name, &tasks[n].priority, &tasks[n].cpuBurst) == 3) {
        tasks[n].remainingTime = tasks[n].cpuBurst;
        tasks[n].waitingTime = 0;
        tasks[n].turnaroundTime = 0;
        tasks[n].completed = 0;
        n++;
    }

    fclose(file);
    return n;
}

void printGanttChart(Task tasks[], int n, const char* algorithm) {
    printf("\nGantt Chart for %s:\n", algorithm);
  
    
    // Print the task execution bars
    printf("|");
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < tasks[i].cpuBurst; j++) {
            printf("-");
        }
        printf("|");
    }
    printf("\n");
    
    // Print the task names
    printf("|");
    for(int i = 0; i < n; i++) {
        int spaces = tasks[i].cpuBurst/2;
        for(int j = 0; j < spaces - (strlen(tasks[i].name)/2); j++) printf(" ");
        printf("%s", tasks[i].name);
        for(int j = 0; j < tasks[i].cpuBurst - spaces - (strlen(tasks[i].name) - strlen(tasks[i].name)/2); j++) printf(" ");
        printf("|");
    }
    printf("\n");
    
    // Print the time markers
    printf("0");
    int currentTime = 0;
    for(int i = 0; i < n; i++) {
        currentTime += tasks[i].cpuBurst;
        for(int j = 0; j < tasks[i].cpuBurst-1; j++) printf(" ");
        printf("%d", currentTime);
    }
    printf("\n");
   
}

// Modify each scheduling function to include the Gantt chart. Here's how to update them:

void fcfs(Task tasks[], int n) {
    Task tempTasks[tasks_n];
    memcpy(tempTasks, tasks, sizeof(Task) * n);
    
    int currentTime = 0;
    for (int i = 0; i < n; i++) {
        tempTasks[i].waitingTime = currentTime;
        tempTasks[i].turnaroundTime = currentTime + tempTasks[i].cpuBurst;
        currentTime += tempTasks[i].cpuBurst;
    }
    
    printScheduleTable(tempTasks, n, "FCFS");
    printGanttChart(tempTasks, n, "FCFS");
}

void sjf(Task tasks[], int n) {
    Task tempTasks[tasks_n];
    memcpy(tempTasks, tasks, sizeof(Task) * n);
    
    // Sort by CPU burst time
    for (int i = 0; i < n-1; i++) {
        for (int j = 0; j < n-i-1; j++) {
            if (tempTasks[j].cpuBurst > tempTasks[j+1].cpuBurst) {
                Task temp = tempTasks[j];
                tempTasks[j] = tempTasks[j+1];
                tempTasks[j+1] = temp;
            }
        }
    }
    
    int currentTime = 0;
    for (int i = 0; i < n; i++) {
        tempTasks[i].waitingTime = currentTime;
        tempTasks[i].turnaroundTime = currentTime + tempTasks[i].cpuBurst;
        currentTime += tempTasks[i].cpuBurst;
    }
    
    printScheduleTable(tempTasks, n, "SJF");
    printGanttChart(tempTasks, n, "SJF");
}

void priorityScheduling(Task tasks[], int n) {
    Task tempTasks[tasks_n];
    memcpy(tempTasks, tasks, sizeof(Task) * n);
    
    // Sort by priority
    for (int i = 0; i < n-1; i++) {
        for (int j = 0; j < n-i-1; j++) {
            if (tempTasks[j].priority > tempTasks[j+1].priority) {
                Task temp = tempTasks[j];
                tempTasks[j] = tempTasks[j+1];
                tempTasks[j+1] = temp;
            }
        }
    }
    
    int currentTime = 0;
    for (int i = 0; i < n; i++) {
        tempTasks[i].waitingTime = currentTime;
        tempTasks[i].turnaroundTime = currentTime + tempTasks[i].cpuBurst;
        currentTime += tempTasks[i].cpuBurst;
    }
    
    printScheduleTable(tempTasks, n, "Priority");
    printGanttChart(tempTasks, n, "Priority");
}

void roundRobin(Task tasks[], int n, int timeQuantum) {
    Task tempTasks[tasks_n];
    memcpy(tempTasks, tasks, sizeof(Task) * n);
    
    // Array to store execution order for Gantt chart
    Task executionOrder[100];  // Assuming max 100 time slices
    int executionCount = 0;
    
    int remainingTasks = n;
    int currentTime = 0;
    
    // Initialize remaining time
    for (int i = 0; i < n; i++) {
        tempTasks[i].remainingTime = tempTasks[i].cpuBurst;
    }
    
    while (remainingTasks > 0) {
        for (int i = 0; i < n; i++) {
            if (tempTasks[i].remainingTime > 0) {
                int executeTime = (tempTasks[i].remainingTime > timeQuantum) ? 
                                 timeQuantum : tempTasks[i].remainingTime;
                
                // Store execution step for Gantt chart
                executionOrder[executionCount] = tempTasks[i];
                executionOrder[executionCount].cpuBurst = executeTime;
                executionCount++;
                
                tempTasks[i].remainingTime -= executeTime;
                currentTime += executeTime;
                
                if (tempTasks[i].remainingTime == 0) {
                    remainingTasks--;
                    tempTasks[i].turnaroundTime = currentTime;
                    tempTasks[i].waitingTime = tempTasks[i].turnaroundTime - tempTasks[i].cpuBurst;
                }
            }
        }
    }
    
    printScheduleTable(tempTasks, n, "Round Robin");
    printGanttChart(executionOrder, executionCount, "Round Robin");
}

void priorityRoundRobin(Task tasks[], int n, int timeQuantum) {
    Task tempTasks[tasks_n];
    memcpy(tempTasks, tasks, sizeof(Task) * n);
    
    // Array to store execution order for Gantt chart
    Task executionOrder[100];  // Assuming max 100 time slices
    int executionCount = 0;
    
    int remainingTasks = n;
    int currentTime = 0;
    
    // Initialize remaining time
    for (int i = 0; i < n; i++) {
        tempTasks[i].remainingTime = tempTasks[i].cpuBurst;
    }
    
    while (remainingTasks > 0) {
        int highestPriority = INT_MAX;
        for (int i = 0; i < n; i++) {
            if (tempTasks[i].remainingTime > 0 && tempTasks[i].priority < highestPriority) {
                highestPriority = tempTasks[i].priority;
            }
        }
        
        int taskExecuted = 0;
        for (int i = 0; i < n; i++) {
            if (tempTasks[i].remainingTime > 0 && tempTasks[i].priority == highestPriority) {
                int executeTime = (tempTasks[i].remainingTime > timeQuantum) ? 
                                 timeQuantum : tempTasks[i].remainingTime;
                
                // Store execution step for Gantt chart
                executionOrder[executionCount] = tempTasks[i];
                executionOrder[executionCount].cpuBurst = executeTime;
                executionCount++;
                
                tempTasks[i].remainingTime -= executeTime;
                currentTime += executeTime;
                taskExecuted = 1;
                
                if (tempTasks[i].remainingTime == 0) {
                    remainingTasks--;
                    tempTasks[i].turnaroundTime = currentTime;
                    tempTasks[i].waitingTime = tempTasks[i].turnaroundTime - tempTasks[i].cpuBurst;
                }
            }
        }
        
        if (!taskExecuted) break;
    }
    
    printScheduleTable(tempTasks, n, "Priority Round Robin");
    printGanttChart(executionOrder, executionCount, "Priority Round Robin");
}

int main() {
    Task tasks[tasks_n];
    int n = loadTasks(tasks, "schedule.txt");
    
    if (n == 0) {
        printf("No tasks loaded!\n");
        return 1;
    }
    
    printf("CPU Scheduling Simulator\n");
    printLine(50);
    printf("Loaded %d tasks.\n\n", n);
    
    // Execute all scheduling algorithms
    fcfs(tasks, n);
    sjf(tasks, n);
    priorityScheduling(tasks, n);
    roundRobin(tasks, n, time_quantum);
    priorityRoundRobin(tasks, n, time_quantum);
    
    return 0;
}