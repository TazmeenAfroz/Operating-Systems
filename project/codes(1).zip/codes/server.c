#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <errno.h>
#include <signal.h>
#include <time.h>

#define PORT 8080
#define MAX_CLIENTS 4
#define SERVER_PREFIX "SERVER: "
#define LOG_FILE "server_log.txt"
#define MAX_MESSAGE_LENGTH 1024

typedef struct {
    int socket;
    int id;
    char messages[100][1024];
    int msg_count;
    int active;
} Client;

// Global variables
Client clients[MAX_CLIENTS];
int client_count = 0;
sem_t server_semaphore;  
int server_running = 1;

void log_error(const char *message) {
    FILE *log_file = fopen(LOG_FILE, "a");
    if (log_file == NULL) {
        perror("Failed to open log file");
        return;
    }
    fprintf(log_file, "ERROR: %s: %s\n", message, strerror(errno));
    fclose(log_file);
}

void broadcast_message(const char *message) {
    char broadcast_message[1050];
    snprintf(broadcast_message, sizeof(broadcast_message), "%s%s", SERVER_PREFIX, message);

    sem_wait(&server_semaphore);  // Lock with semaphore
    for (int i = 0; i < client_count; i++) {
        if (clients[i].active) {
            if (send(clients[i].socket, broadcast_message, strlen(broadcast_message), 0) < 0) {
                perror("Send failed");
                log_error("Send failed");
            }
        }
    }
    sem_post(&server_semaphore);  // Unlock with semaphore
}

void store_client_message(int client_id, const char *message) {
    sem_wait(&server_semaphore);
    int msg_idx = clients[client_id].msg_count % 100;
    strncpy(clients[client_id].messages[msg_idx], message, 1024);
    clients[client_id].msg_count++;
    sem_post(&server_semaphore);
}

void show_menu() {
    printf("\n=== Server Menu ===\n");
    printf("1. Send Broadcast Message\n");
    printf("2. View Individual Client Messages\n");
    printf("3. Exit\n");
    printf("Enter choice : ");
}

void *handle_client(void *client_data) {
    Client *client = (Client*)client_data;
    int read_size;
    char client_message[1024];
    char display_message[1100];

    printf("\nClient %d connected\n", client->id);

    while (server_running && (read_size = recv(client->socket, client_message, 1024, 0)) > 0) {
        client_message[read_size] = '\0';
        
        snprintf(display_message, sizeof(display_message), "Client %d: %s", client->id, client_message);
        store_client_message(client->id, display_message);
        
        printf("\n%s\n", display_message);
    }

    sem_wait(&server_semaphore);
    client->active = 0;
    printf("\nClient %d disconnected\n", client->id);
    sem_post(&server_semaphore);

    close(client->socket);
    return 0;
}

void view_individual_messages() {
    int client_id;
    printf("\nActive clients:\n");
    
    sem_wait(&server_semaphore);
    for (int i = 0; i < client_count; i++) {
        if (clients[i].active) {
            printf("Client %d\n", i);
        }
    }
    sem_post(&server_semaphore);
    
    printf("Enter client ID to view messages: ");
    scanf("%d", &client_id);
    getchar(); // Clear newline
    
    if (client_id >= 0 && client_id < client_count) {
        printf("\nMessages from Client %d:\n", client_id);
        sem_wait(&server_semaphore);
        int start = (clients[client_id].msg_count > 100) ? 
                   clients[client_id].msg_count - 100 : 0;
        for (int i = start; i < clients[client_id].msg_count; i++) {
            printf("%s\n", clients[client_id].messages[i % 100]);
        }
        sem_post(&server_semaphore);
    } else {
        printf("Invalid client ID\n");
    }
}

void *server_menu(void *arg) {
    int choice;
    char input[1024];
    char broadcast_msg[1024];

    show_menu();

    while (server_running) {
        fgets(input, sizeof(input), stdin);
        choice = atoi(input);

        switch (choice) {
            case 1:
                printf("Enter message to broadcast: ");
                fgets(broadcast_msg, sizeof(broadcast_msg), stdin);
                broadcast_msg[strcspn(broadcast_msg, "\n")] = '\0';
                broadcast_message(broadcast_msg);
                printf("Message broadcasted\n");
                break;
                
            case 2:
                view_individual_messages();
                break;
                
            case 3:
                printf("\nShutting down server...\n");
                server_running = 0;
                sem_wait(&server_semaphore);
                for (int i = 0; i < client_count; i++) {
                    if (clients[i].active) {
                        send(clients[i].socket, "SERVER_SHUTDOWN", 14, 0);
                        close(clients[i].socket);
                    }
                }
                sem_post(&server_semaphore);
                exit(0);
                break;
                
            default:
                printf("Invalid choice!\n");
                show_menu();
        }
    }
    return 0;
}

int main() {
    int server_fd, new_socket, c;
    struct sockaddr_in server, client;
    pthread_t thread_id, menu_thread;

    // Initialize semaphore
    if (sem_init(&server_semaphore, 0, 1) < 0) {
        perror("Semaphore initialization failed");
        return 1;
    }

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd == -1) {
        perror("Could not create socket");
        log_error("Could not create socket");
        return 1;
    }

    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("bind failed");
        log_error("bind failed");
        return 1;
    }

    listen(server_fd, 3);
    printf("Server started on port %d\n", PORT);
    printf("Showing all client activity - Use menu for additional options\n");

    if (pthread_create(&menu_thread, NULL, server_menu, NULL) < 0) {
        perror("could not create menu thread");
        log_error("could not create menu thread");
        return 1;
    }

    c = sizeof(struct sockaddr_in);
    while (server_running && (new_socket = accept(server_fd, (struct sockaddr *)&client, (socklen_t*)&c))) {
        if (new_socket < 0) {
            perror("accept failed");
            log_error("accept failed");
            continue;
        }

        sem_wait(&server_semaphore);
        if (client_count >= MAX_CLIENTS) {
            send(new_socket, "Server is full", 13, 0);
            close(new_socket);
            sem_post(&server_semaphore);
            continue;
        }

        clients[client_count].socket = new_socket;
        clients[client_count].id = client_count;
        clients[client_count].active = 1;
        clients[client_count].msg_count = 0;

        if (pthread_create(&thread_id, NULL, handle_client, (void*)&clients[client_count]) < 0) {
            perror("could not create thread");
            log_error("could not create thread");
            sem_post(&server_semaphore);
            return 1;
        }

        client_count++;
        sem_post(&server_semaphore);
    }

    sem_destroy(&server_semaphore);
    return 0;
}